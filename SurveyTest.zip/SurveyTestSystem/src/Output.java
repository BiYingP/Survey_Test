

public abstract class Output {

	public Output() { }

	public abstract void display(String s);
}