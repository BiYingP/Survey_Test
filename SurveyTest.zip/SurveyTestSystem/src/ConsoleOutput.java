public class ConsoleOutput extends Output {
    public ConsoleOutput(){

    }
    public void display(String s){
        System.out.println(s);
    }
}
